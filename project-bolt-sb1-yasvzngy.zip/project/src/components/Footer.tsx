import { Phone, Mail, MapPin, Instagram } from 'lucide-react';

export default function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <footer className="bg-stone-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <img src="/image.png" alt="Ideas & More Logo" className="w-10 h-10 rounded-lg object-cover" />
              <div>
                <h3 className="text-lg font-semibold">Ideas & More</h3>
                <p className="text-xs text-stone-400">Furniture Manufacturers</p>
              </div>
            </div>
            <p className="text-stone-400 text-sm leading-relaxed font-light">
              Full-scale furniture manufacturing with in-house production facility in Ludhiana. Quality craftsmanship for homes and businesses.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => scrollToSection('about')} className="text-stone-400 hover:text-stone-300 transition-colors text-sm font-light">
                  About Us
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('materials')} className="text-stone-400 hover:text-stone-300 transition-colors text-sm font-light">
                  Materials
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('furniture')} className="text-stone-400 hover:text-stone-300 transition-colors text-sm font-light">
                  Furniture
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('why-us')} className="text-stone-400 hover:text-stone-300 transition-colors text-sm font-light">
                  Why Choose Us
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('contact')} className="text-stone-400 hover:text-stone-300 transition-colors text-sm font-light">
                  Contact
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact Info</h4>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <Phone className="w-4 h-4 text-stone-400 mt-1 flex-shrink-0" />
                <a href="tel:+919815600908" className="text-stone-400 hover:text-stone-300 transition-colors text-sm font-light">
                  +91 98156 00908
                </a>
              </li>
              <li className="flex items-start space-x-3">
                <Mail className="w-4 h-4 text-stone-400 mt-1 flex-shrink-0" />
                <a href="mailto:ideasandmore908@gmail.com" className="text-stone-400 hover:text-stone-300 transition-colors text-sm font-light break-all">
                  ideasandmore908@gmail.com
                </a>
              </li>
              <li className="flex items-start space-x-3">
                <Instagram className="w-4 h-4 text-stone-400 mt-1 flex-shrink-0" />
                <a href="https://instagram.com/ideasnmore2024" target="_blank" rel="noopener noreferrer" className="text-stone-400 hover:text-stone-300 transition-colors text-sm font-light">
                  @ideasnmore2024
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Our Locations</h4>
            <div className="space-y-4">
              <div>
                <div className="flex items-start space-x-2 mb-1">
                  <MapPin className="w-4 h-4 text-stone-400 mt-1 flex-shrink-0" />
                  <div>
                    <div className="text-sm font-semibold text-white mb-1">Office</div>
                    <p className="text-stone-400 text-xs font-light">Shop No. 343, Bus Stand Road, Ludhiana</p>
                  </div>
                </div>
              </div>
              <div>
                <div className="flex items-start space-x-2 mb-1">
                  <MapPin className="w-4 h-4 text-stone-400 mt-1 flex-shrink-0" />
                  <div>
                    <div className="text-sm font-semibold text-white mb-1">Factory</div>
                    <p className="text-stone-400 text-xs font-light">Plot No. 30, Bhagwanpura, Near Tibba Bridge, Ludhiana</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-stone-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-stone-400 text-sm text-center md:text-left font-light">
              © {new Date().getFullYear()} Ideas & More. All rights reserved.
            </p>
            <p className="text-stone-400 text-sm text-center md:text-right font-light">
              Crafted with precision in Ludhiana, Punjab
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
