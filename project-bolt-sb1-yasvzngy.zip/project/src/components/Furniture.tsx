import { Sofa, DoorOpen, Tv, Bed, Briefcase, Armchair, Box } from 'lucide-react';

export default function Furniture() {
  const categories = [
    {
      icon: DoorOpen,
      name: 'Modular Kitchens',
      description: 'Contemporary designs with smart storage solutions',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      icon: Box,
      name: 'Wardrobes',
      description: 'Custom-built with sliding doors & organizers',
      gradient: 'from-stone-500 to-stone-700'
    },
    {
      icon: Tv,
      name: 'TV Units',
      description: 'Modern entertainment units & wall panels',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      icon: Bed,
      name: 'Beds & Nightstands',
      description: 'Comfortable designs with storage options',
      gradient: 'from-stone-500 to-stone-700'
    },
    {
      icon: Briefcase,
      name: 'Office Furniture',
      description: 'Modular workstations & office solutions',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      icon: Armchair,
      name: 'Tables & Chairs',
      description: 'Dining sets, study tables & seating',
      gradient: 'from-stone-500 to-stone-700'
    },
    {
      icon: Box,
      name: 'Storage Units',
      description: 'Shoe racks, cabinets & organizers',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      icon: Sofa,
      name: 'Custom Interiors',
      description: 'Bespoke furniture for unique spaces',
      gradient: 'from-stone-500 to-stone-700'
    }
  ];

  return (
    <section id="furniture" className="py-20 bg-gradient-to-br from-stone-50 via-white to-stone-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-stone-200 text-stone-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Sofa className="w-4 h-4" />
            <span>Manufacturing Excellence</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900 mb-4">
            Furniture We Manufacture
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-light">
            Complete modular and custom furniture manufactured in our own factory with precision craftsmanship and modern machinery.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <div
                key={index}
                className="group bg-white rounded-2xl p-6 shadow-sm border border-stone-200 hover:shadow-xl transition-all hover:-translate-y-1"
              >
                <div className={`w-14 h-14 bg-gradient-to-br ${category.gradient} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{category.name}</h3>
                <p className="text-sm text-gray-600 font-light">{category.description}</p>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-r from-stone-700 to-stone-900 rounded-3xl p-8 sm:p-12 text-white">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl sm:text-3xl font-semibold mb-4">Custom Manufacturing Process</h3>
              <p className="text-stone-100 mb-6 leading-relaxed font-light">
                Every piece of furniture is crafted with attention to detail in our state-of-the-art manufacturing facility. From design consultation to final installation, we ensure premium quality at every step.
              </p>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-stone-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-white text-xs font-bold">1</span>
                  </div>
                  <div>
                    <div className="font-semibold mb-1">Design Consultation</div>
                    <div className="text-sm text-stone-200 font-light">Understand your requirements & preferences</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-stone-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-white text-xs font-bold">2</span>
                  </div>
                  <div>
                    <div className="font-semibold mb-1">Factory Production</div>
                    <div className="text-sm text-stone-200 font-light">Precision manufacturing with quality materials</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-stone-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-white text-xs font-bold">3</span>
                  </div>
                  <div>
                    <div className="font-semibold mb-1">Expert Installation</div>
                    <div className="text-sm text-stone-200 font-light">Professional setup & after-sales support</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-3xl font-bold text-stone-200 mb-2">100%</div>
                <div className="text-sm text-stone-100 font-light">Custom Designs</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-3xl font-bold text-stone-200 mb-2">Premium</div>
                <div className="text-sm text-stone-100 font-light">Quality Control</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-3xl font-bold text-stone-200 mb-2">Modern</div>
                <div className="text-sm text-stone-100 font-light">Machinery</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <div className="text-3xl font-bold text-stone-200 mb-2">Expert</div>
                <div className="text-sm text-stone-100 font-light">Craftsmen</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
