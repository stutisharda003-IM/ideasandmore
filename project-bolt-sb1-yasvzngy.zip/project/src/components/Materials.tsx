import { Layers, Box } from 'lucide-react';

export default function Materials() {
  const materials = [
    {
      category: 'Plywood',
      items: ['Commercial Plywood', 'BWP Grade', 'BWR Grade', 'Marine Plywood', 'Gurjan Plywood', 'Shuttering Plywood', 'Film Faced Plywood']
    },
    {
      category: 'MDF',
      items: ['Plain MDF', 'Pre-laminated MDF', 'HD MDF', 'Moisture Resistant MDF']
    },
    {
      category: 'Particle Board',
      items: ['Plain Particle Board', 'Pre-laminated Particle Board', 'Moisture Resistant']
    },
    {
      category: 'Specialty Boards',
      items: ['HDF', 'HDHMR Board', 'Blockboard', 'WPC Boards', 'PVC Boards']
    }
  ];

  return (
    <section id="materials" className="py-20 bg-gradient-to-br from-stone-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-stone-200 text-stone-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Layers className="w-4 h-4" />
            <span>Premium Raw Materials</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900 mb-4">
            Wood & Board Materials
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-light">
            We supply a comprehensive range of premium quality wood and board materials for all your furniture and interior needs.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {materials.map((material, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-6 shadow-sm border border-stone-200 hover:shadow-lg hover:border-stone-400 transition-all"
            >
              <div className="w-12 h-12 bg-stone-600 rounded-xl flex items-center justify-center mb-4">
                <Box className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">{material.category}</h3>
              <ul className="space-y-2">
                {material.items.map((item, itemIndex) => (
                  <li key={itemIndex} className="flex items-start space-x-2">
                    <svg className="w-5 h-5 text-stone-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-sm text-gray-600 font-light">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-stone-600 rounded-2xl p-8 text-center text-white">
          <h3 className="text-2xl font-semibold mb-3">Need Help Choosing the Right Material?</h3>
          <p className="text-stone-100 mb-6 max-w-2xl mx-auto font-light">
            Our experts can guide you in selecting the perfect material based on your project requirements, budget, and durability needs.
          </p>
          <button
            onClick={() => {
              const element = document.getElementById('contact');
              if (element) element.scrollIntoView({ behavior: 'smooth' });
            }}
            className="bg-white text-stone-600 px-8 py-3 rounded-md hover:bg-stone-50 transition-colors font-semibold"
          >
            Consult Our Experts
          </button>
        </div>
      </div>
    </section>
  );
}
