import { MapPin, Phone, Mail, Instagram, Building2, Factory } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900 mb-4">
            Get In Touch
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-light">
            Visit our showroom, call us for inquiries, or reach out via email. We're here to help with all your furniture needs.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <div className="bg-gradient-to-br from-stone-100 to-white border border-stone-200 rounded-2xl p-8 hover:shadow-lg transition-shadow">
            <div className="w-14 h-14 bg-stone-600 rounded-xl flex items-center justify-center mb-6">
              <Phone className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Call Us</h3>
            <div className="space-y-3">
              <div>
                <div className="text-sm text-gray-600 mb-1 font-light">Contact Person</div>
                <div className="font-semibold text-gray-900">Sunil Sharda</div>
              </div>
              <div>
                <div className="text-sm text-gray-600 mb-1 font-light">Phone Number</div>
                <a href="tel:+919815600908" className="font-semibold text-stone-600 hover:text-stone-800">
                  +91 98156 00908
                </a>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-stone-50 to-white border border-stone-200 rounded-2xl p-8 hover:shadow-lg transition-shadow">
            <div className="w-14 h-14 bg-stone-500 rounded-xl flex items-center justify-center mb-6">
              <Mail className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Email Us</h3>
            <div className="space-y-3">
              <div>
                <div className="text-sm text-gray-600 mb-1 font-light">Business Inquiries</div>
                <a href="mailto:ideasandmore908@gmail.com" className="font-semibold text-stone-600 hover:text-stone-800 break-all">
                  ideasandmore908@gmail.com
                </a>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-stone-100 to-white border border-stone-200 rounded-2xl p-8 hover:shadow-lg transition-shadow">
            <div className="w-14 h-14 bg-stone-600 rounded-xl flex items-center justify-center mb-6">
              <Instagram className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Follow Us</h3>
            <div className="space-y-3">
              <div>
                <div className="text-sm text-gray-600 mb-1 font-light">Instagram</div>
                <a
                  href="https://instagram.com/ideasnmore2024"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold text-stone-600 hover:text-stone-800"
                >
                  @ideasnmore2024
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-stone-700 text-white rounded-2xl p-8">
            <div className="flex items-start space-x-4 mb-6">
              <div className="w-12 h-12 bg-stone-500 rounded-lg flex items-center justify-center flex-shrink-0">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Office Location</h3>
                <p className="text-stone-100 leading-relaxed font-light">
                  Shop No. 343, Bus Stand Road<br />
                  Ludhiana, Punjab
                </p>
              </div>
            </div>
            <a
              href="https://maps.google.com/?q=Shop+No.+343+Bus+Stand+Road+Ludhiana"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 text-stone-300 hover:text-stone-100 transition-colors"
            >
              <MapPin className="w-4 h-4" />
              <span className="text-sm font-medium">View on Map</span>
            </a>
          </div>

          <div className="bg-stone-600 text-white rounded-2xl p-8">
            <div className="flex items-start space-x-4 mb-6">
              <div className="w-12 h-12 bg-stone-500 rounded-lg flex items-center justify-center flex-shrink-0">
                <Factory className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Factory Location</h3>
                <p className="text-stone-100 leading-relaxed font-light">
                  Plot No. 30, Bhagwanpura<br />
                  Near Tibba Bridge, Ludhiana
                </p>
              </div>
            </div>
            <a
              href="https://maps.google.com/?q=Plot+30+Bhagwanpura+Tibba+Bridge+Ludhiana"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 text-stone-200 hover:text-stone-100 transition-colors"
            >
              <MapPin className="w-4 h-4" />
              <span className="text-sm font-medium">View on Map</span>
            </a>
          </div>
        </div>

        <div className="mt-12 bg-gradient-to-br from-stone-100 to-white border border-stone-200 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-semibold text-gray-900 mb-3">Visit Our Showroom</h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto font-light">
            Experience our extensive range of materials and view sample furniture pieces at our showroom. Our team is ready to assist you with expert guidance and personalized solutions.
          </p>
          <div className="inline-flex items-center space-x-2 text-stone-700 font-medium">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>Open Monday - Saturday: 9:00 AM - 8:00 PM</span>
          </div>
        </div>
      </div>
    </section>
  );
}
