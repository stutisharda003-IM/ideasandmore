import { Settings, Move, Hand, ArrowUpCircle } from 'lucide-react';

export default function Hardware() {
  const hardwareCategories = [
    {
      icon: Settings,
      name: 'Hinges',
      items: ['Soft-Close Hinges', 'Normal Hinges', 'Concealed Hinges', 'Piano Hinges', 'Glass Door Hinges'],
      color: 'stone'
    },
    {
      icon: Move,
      name: 'Drawer Systems',
      items: ['Telescopic Channels', 'Soft-Close Channels', 'Tandem Drawer System', 'Slim Box Drawers', 'Heavy-Duty Channels'],
      color: 'gray'
    },
    {
      icon: Hand,
      name: 'Handles & Knobs',
      items: ['Cabinet Handles', 'Door Knobs', 'Pull Handles', 'Edge Pulls', 'Designer Hardware'],
      color: 'stone'
    },
    {
      icon: ArrowUpCircle,
      name: 'Special Systems',
      items: ['Lift-up Systems', 'Sliding Door Systems', 'Wardrobe Fittings', 'Modular Accessories'],
      color: 'gray'
    }
  ];

  const kitchenAccessories = [
    'Bottle Pullout',
    'Pantry Pullout',
    'Corner Unit Solutions',
    'Cutlery Tray',
    'Plate Organizer',
    'Thali Basket',
    'Tandem Unit',
    'Magic Corner'
  ];

  return (
    <section id="hardware" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-stone-200 text-stone-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Settings className="w-4 h-4" />
            <span>Premium Hardware</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900 mb-4">
            Quality Hardware & Fittings
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-light">
            We use only premium brand hardware to ensure durability, smooth operation, and long-lasting performance of your furniture.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {hardwareCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <div
                key={index}
                className={`${
                  category.color === 'stone'
                    ? 'bg-gradient-to-br from-stone-100 to-white border-stone-200'
                    : 'bg-gradient-to-br from-gray-50 to-white border-stone-200'
                } border rounded-2xl p-6 hover:shadow-lg transition-all`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${
                  category.color === 'stone' ? 'bg-stone-600' : 'bg-stone-500'
                }`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{category.name}</h3>
                <ul className="space-y-2">
                  {category.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start space-x-2">
                      <div className={`w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0 ${
                        category.color === 'stone' ? 'bg-stone-600' : 'bg-stone-500'
                      }`}></div>
                      <span className="text-sm text-gray-600 font-light">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <div className="bg-stone-600 rounded-3xl p-8 sm:p-12 text-white">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl sm:text-3xl font-semibold mb-4">Kitchen Accessories</h3>
              <p className="text-stone-100 mb-6 leading-relaxed font-light">
                Smart storage solutions and modular accessories that maximize space utilization and enhance functionality in your modular kitchen.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {kitchenAccessories.map((accessory, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <svg className="w-5 h-5 text-stone-300 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-sm font-light">{accessory}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
              <h4 className="text-xl font-semibold mb-6">Premium Brands We Use</h4>
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-4 border-b border-white/20">
                  <span className="font-medium">Hardware Quality</span>
                  <span className="text-stone-200 font-light">Premium Grade</span>
                </div>
                <div className="flex items-center justify-between pb-4 border-b border-white/20">
                  <span className="font-medium">Warranty Coverage</span>
                  <span className="text-stone-200 font-light">Manufacturer Backed</span>
                </div>
                <div className="flex items-center justify-between pb-4 border-b border-white/20">
                  <span className="font-medium">Durability</span>
                  <span className="text-stone-200 font-light">Long-lasting</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-medium">Finish Options</span>
                  <span className="text-stone-200 font-light">Multiple Available</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
