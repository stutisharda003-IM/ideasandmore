import { Building2, Users, MapPin } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900 mb-4">
            About Ideas & More
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-light">
            A full-scale furniture manufacturing company based in Ludhiana, specializing in complete modular and custom furniture with our own production facility.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-gradient-to-br from-stone-100 to-white p-8 rounded-2xl border border-stone-200">
            <div className="w-14 h-14 bg-stone-600 rounded-xl flex items-center justify-center mb-6">
              <Building2 className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Manufacturing Excellence</h3>
            <p className="text-gray-600 leading-relaxed font-light">
              Complete in-house manufacturing facility equipped with modern machinery and skilled craftsmen ensuring premium quality output.
            </p>
          </div>

          <div className="bg-gradient-to-br from-stone-50 to-white p-8 rounded-2xl border border-stone-200">
            <div className="w-14 h-14 bg-stone-500 rounded-xl flex items-center justify-center mb-6">
              <Users className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Diverse Clientele</h3>
            <p className="text-gray-600 leading-relaxed font-light">
              We serve homeowners, offices, interior designers, builders, architects, and retail customers across all segments.
            </p>
          </div>

          <div className="bg-gradient-to-br from-stone-100 to-white p-8 rounded-2xl border border-stone-200">
            <div className="w-14 h-14 bg-stone-600 rounded-xl flex items-center justify-center mb-6">
              <MapPin className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Ludhiana Based</h3>
            <p className="text-gray-600 leading-relaxed font-light">
              Strategically located with both office and factory facilities, ensuring efficient service delivery and quality control.
            </p>
          </div>
        </div>

        <div className="bg-stone-700 rounded-3xl p-8 sm:p-12 text-white">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl sm:text-3xl font-semibold mb-6">What Sets Us Apart</h3>
              <p className="text-stone-100 text-lg leading-relaxed mb-6 font-light">
                We're not just manufacturers – we're complete furniture solution providers. From premium raw materials to finished custom furniture, we handle every aspect of your project with expertise and precision.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-stone-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-stone-50">Complete raw material supply chain</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-stone-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-stone-50">Custom furniture manufacturing</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-stone-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-stone-50">End-to-end project management</span>
                </li>
              </ul>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
              <div className="space-y-6">
                <div>
                  <div className="text-stone-300 text-sm font-semibold mb-2">MATERIALS</div>
                  <div className="text-2xl font-semibold">Plywood, Laminates, Boards & Hardware</div>
                </div>
                <div className="h-px bg-white/20"></div>
                <div>
                  <div className="text-stone-300 text-sm font-semibold mb-2">FURNITURE</div>
                  <div className="text-2xl font-semibold">Modular & Custom Manufacturing</div>
                </div>
                <div className="h-px bg-white/20"></div>
                <div>
                  <div className="text-stone-300 text-sm font-semibold mb-2">SERVICE</div>
                  <div className="text-2xl font-semibold">Design to Installation</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
