import { ArrowRight, Factory, Hammer, Sparkles } from 'lucide-react';

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section className="pt-24 pb-16 sm:pt-32 sm:pb-24 bg-gradient-to-br from-amber-50 via-white to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center space-x-2 bg-amber-100 text-amber-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4" />
              <span>Premium Furniture Manufacturing</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              Crafting Quality
              <span className="block text-amber-700">From Factory to Home</span>
            </h1>

            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Full-scale furniture manufacturing with in-house production facility in Ludhiana. We manufacture complete modular furniture and supply premium raw materials to homeowners, designers, builders, and architects.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => scrollToSection('contact')}
                className="inline-flex items-center justify-center bg-amber-700 text-white px-8 py-4 rounded-lg hover:bg-amber-800 transition-all font-semibold shadow-lg hover:shadow-xl"
              >
                Get Quote
                <ArrowRight className="ml-2 w-5 h-5" />
              </button>
              <button
                onClick={() => scrollToSection('materials')}
                className="inline-flex items-center justify-center border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-lg hover:border-amber-700 hover:text-amber-700 transition-all font-semibold"
              >
                Explore Products
              </button>
            </div>

            <div className="grid grid-cols-3 gap-6 mt-12 pt-12 border-t border-gray-200">
              <div>
                <div className="text-3xl font-bold text-amber-700 mb-1">500+</div>
                <div className="text-sm text-gray-600">Projects Completed</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-amber-700 mb-1">20+</div>
                <div className="text-sm text-gray-600">Years Experience</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-amber-700 mb-1">100%</div>
                <div className="text-sm text-gray-600">Quality Assured</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                  <Factory className="w-10 h-10 text-amber-700 mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">Own Factory</h3>
                  <p className="text-sm text-gray-600">State-of-the-art manufacturing facility</p>
                </div>
                <div className="bg-amber-700 p-6 rounded-2xl shadow-lg text-white hover:shadow-xl transition-shadow">
                  <Hammer className="w-10 h-10 mb-3" />
                  <h3 className="font-semibold mb-2">Custom Designs</h3>
                  <p className="text-sm text-amber-100">Tailored to your vision</p>
                </div>
              </div>
              <div className="space-y-4 mt-8">
                <div className="bg-gray-900 p-6 rounded-2xl shadow-lg text-white hover:shadow-xl transition-shadow">
                  <div className="text-3xl font-bold mb-2">50+</div>
                  <p className="text-sm text-gray-300">Premium Material Options</p>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                  <div className="text-2xl font-bold text-amber-700 mb-2">Raw Materials</div>
                  <p className="text-sm text-gray-600">Plywood, laminates, hardware & more</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
