import { Palette, Sparkles } from 'lucide-react';

export default function Finishes() {
  const finishes = [
    {
      name: 'Laminates',
      types: ['0.8mm Standard', '1mm Thickness', 'High-Gloss Finish', 'Matte Finish', 'Textured', 'Anti-finger Print', 'Acrylic Laminates', 'Veneer Laminates'],
      color: 'stone'
    },
    {
      name: 'Natural Veneers',
      types: ['Natural Wood Veneer', 'Reconstituted Veneer', 'Dyed Veneer', 'Smoked Veneer', 'Premium Finishes'],
      color: 'gray'
    },
    {
      name: 'Premium Surfaces',
      types: ['Sunmica Sheets', 'Acrylic Sheets', 'PU Polish', 'Duco Paint', 'Custom Finishes'],
      color: 'stone'
    },
    {
      name: 'Edge Banding',
      types: ['PVC Edge Banding 0.8mm', 'PVC Edge Banding 1mm', 'PVC Edge Banding 2mm', 'Matching Colors', 'Pre-glued Options'],
      color: 'gray'
    }
  ];

  return (
    <section id="finishes" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-stone-200 text-stone-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Palette className="w-4 h-4" />
            <span>Surface Solutions</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900 mb-4">
            Premium Surface Finishes
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-light">
            Transform your furniture with our extensive range of decorative finishes, laminates, veneers, and surface treatments.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {finishes.map((finish, index) => (
            <div
              key={index}
              className={`${
                finish.color === 'stone'
                  ? 'bg-gradient-to-br from-stone-100 to-white border-stone-200'
                  : 'bg-gradient-to-br from-gray-50 to-white border-stone-200'
              } border rounded-2xl p-8 hover:shadow-lg transition-all`}
            >
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-2xl font-semibold text-gray-900 mb-2">{finish.name}</h3>
                  <div className="text-sm text-gray-500">{finish.types.length} Options Available</div>
                </div>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  finish.color === 'stone' ? 'bg-stone-600' : 'bg-stone-500'
                }`}>
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2">
                {finish.types.map((type, typeIndex) => (
                  <div
                    key={typeIndex}
                    className="flex items-center space-x-3 py-2"
                  >
                    <div className={`w-1.5 h-1.5 rounded-full ${
                      finish.color === 'stone' ? 'bg-stone-600' : 'bg-stone-500'
                    }`}></div>
                    <span className="text-gray-700 font-light">{type}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-gray-800 text-white p-6 rounded-2xl">
            <div className="text-3xl font-semibold mb-2">500+</div>
            <div className="text-gray-300 font-light">Design Options</div>
          </div>
          <div className="bg-stone-600 text-white p-6 rounded-2xl">
            <div className="text-3xl font-semibold mb-2">Premium</div>
            <div className="text-stone-100 font-light">Quality Brands</div>
          </div>
          <div className="bg-gray-800 text-white p-6 rounded-2xl">
            <div className="text-3xl font-semibold mb-2">Latest</div>
            <div className="text-gray-300 font-light">Trends & Patterns</div>
          </div>
        </div>
      </div>
    </section>
  );
}
