import { Menu, X, Phone, Mail } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-600 to-amber-800 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">I&M</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Ideas & More</h1>
              <p className="text-xs text-gray-600">Furniture Manufacturers</p>
            </div>
          </div>

          <nav className="hidden lg:flex items-center space-x-8">
            <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-amber-700 transition-colors font-medium">About</button>
            <button onClick={() => scrollToSection('materials')} className="text-gray-700 hover:text-amber-700 transition-colors font-medium">Materials</button>
            <button onClick={() => scrollToSection('furniture')} className="text-gray-700 hover:text-amber-700 transition-colors font-medium">Furniture</button>
            <button onClick={() => scrollToSection('why-us')} className="text-gray-700 hover:text-amber-700 transition-colors font-medium">Why Us</button>
            <button onClick={() => scrollToSection('contact')} className="bg-amber-700 text-white px-6 py-2 rounded-lg hover:bg-amber-800 transition-colors font-medium">Contact</button>
          </nav>

          <div className="flex lg:hidden items-center space-x-4">
            <a href="tel:+919815600908" className="text-amber-700">
              <Phone className="w-5 h-5" />
            </a>
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-700">
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="lg:hidden pb-4 border-t border-gray-100 mt-2 pt-4">
            <nav className="flex flex-col space-y-3">
              <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-amber-700 transition-colors font-medium text-left">About</button>
              <button onClick={() => scrollToSection('materials')} className="text-gray-700 hover:text-amber-700 transition-colors font-medium text-left">Materials</button>
              <button onClick={() => scrollToSection('furniture')} className="text-gray-700 hover:text-amber-700 transition-colors font-medium text-left">Furniture</button>
              <button onClick={() => scrollToSection('why-us')} className="text-gray-700 hover:text-amber-700 transition-colors font-medium text-left">Why Us</button>
              <button onClick={() => scrollToSection('contact')} className="bg-amber-700 text-white px-6 py-2 rounded-lg hover:bg-amber-800 transition-colors font-medium text-left">Contact</button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
