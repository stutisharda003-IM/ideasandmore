import { Factory, Award, Clock, Wrench, Users, Shield, Truck, HeadphonesIcon } from 'lucide-react';

export default function WhyChooseUs() {
  const reasons = [
    {
      icon: Factory,
      title: 'In-House Manufacturing',
      description: 'Our own factory ensures complete quality control and competitive pricing',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      icon: Award,
      title: 'Premium Materials',
      description: 'We use only the finest quality raw materials from trusted brands',
      gradient: 'from-stone-500 to-stone-700'
    },
    {
      icon: Users,
      title: 'Experienced Craftsmen',
      description: 'Skilled artisans with years of expertise in furniture manufacturing',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      icon: Wrench,
      title: 'Modern Machinery',
      description: 'State-of-the-art equipment for precision and efficiency',
      gradient: 'from-stone-500 to-stone-700'
    },
    {
      icon: Shield,
      title: 'Customized Designs',
      description: 'Tailored solutions to match your unique style and requirements',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      icon: Clock,
      title: 'On-Time Delivery',
      description: 'Committed to project timelines with efficient execution',
      gradient: 'from-stone-500 to-stone-700'
    },
    {
      icon: Truck,
      title: 'End-to-End Service',
      description: 'From design consultation to installation and handover',
      gradient: 'from-stone-600 to-stone-800'
    },
    {
      icon: HeadphonesIcon,
      title: 'After-Sales Support',
      description: 'Dedicated support team for maintenance and service',
      gradient: 'from-stone-500 to-stone-700'
    }
  ];

  return (
    <section id="why-us" className="py-20 bg-gradient-to-br from-stone-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-stone-200 text-stone-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Award className="w-4 h-4" />
            <span>Our Advantages</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-light text-gray-900 mb-4">
            Why Choose Ideas & More
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto font-light">
            We combine manufacturing excellence with customer-centric service to deliver furniture that exceeds expectations.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-2xl p-6 shadow-sm border border-stone-200 hover:shadow-xl hover:-translate-y-1 transition-all"
              >
                <div className={`w-14 h-14 bg-gradient-to-br ${reason.gradient} rounded-xl flex items-center justify-center mb-4`}>
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{reason.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed font-light">{reason.description}</p>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-r from-stone-600 to-stone-800 rounded-3xl p-8 sm:p-12 text-white text-center">
          <h3 className="text-2xl sm:text-3xl font-semibold mb-4">
            Ready to Transform Your Space?
          </h3>
          <p className="text-stone-100 max-w-2xl mx-auto mb-8 text-lg font-light">
            Whether you need premium materials or complete custom furniture, we're here to bring your vision to life with expert craftsmanship and reliable service.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => {
                const element = document.getElementById('contact');
                if (element) element.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-white text-stone-700 px-8 py-4 rounded-md hover:bg-stone-50 transition-colors font-semibold shadow-lg"
            >
              Get Free Quote
            </button>
            <a
              href="tel:+919815600908"
              className="border-2 border-white text-white px-8 py-4 rounded-md hover:bg-white/10 transition-colors font-semibold"
            >
              Call Now: +91 98156 00908
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
