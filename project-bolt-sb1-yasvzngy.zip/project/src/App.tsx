import Hero from './components/Hero';
import About from './components/About';
import Materials from './components/Materials';
import Finishes from './components/Finishes';
import Furniture from './components/Furniture';
import Hardware from './components/Hardware';
import WhyChooseUs from './components/WhyChooseUs';
import Contact from './components/Contact';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <About />
      <Materials />
      <Finishes />
      <Furniture />
      <Hardware />
      <WhyChooseUs />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
